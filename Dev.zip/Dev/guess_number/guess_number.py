class CipherMaster:
    alphabet = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'

    def __init__(self):
        self.shift = 0

    def cipher(self, original_text, shift):
        # Метод должен возвращать зашифрованный текст
        # с учетом переданного смещения shift.
        s = original_text.lower()
        res = ''
        for i in s:
            if i in CipherMaster.alphabet:
                index = CipherMaster.alphabet.find(i)
                new_index = index + shift
                res += CipherMaster.alphabet[new_index % 33]
            else:
                res += i
        return res

    def decipher(self, cipher_text, shift):
        # Метод должен возвращать исходный текст
        # с учётом переданного смещения shift.
        s = cipher_text.lower()
        res = ''
        for i in s:
            if i in CipherMaster.alphabet:
                index = CipherMaster.alphabet.find(i)
                new_index = index - shift
                res += CipherMaster.alphabet[new_index % 33]
            else:
                res += i
        return res


cipher_master = CipherMaster()
print(cipher_master.cipher(
    original_text='Однажды ревьюер принял проект с первого раза, с тех пор я его боюсь',
    shift=2
))
print(cipher_master.decipher(
    cipher_text='Олебэи яфвнэ мроплж сэжи — э пэй рдв злййвкпш лп нвящывнэ',
    shift=-3
))

def say_hello():
    print('Привет, Практикум!')
